package com.example.demo_examenfinal_2025_2;

import com.example.demo_examenfinal_2025_2.entity.Employee;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

@RestController
public class BuscarController {

    @Autowired
    private ServiceBuscarClient serviceBuscarClient;

    final CircuitBreakerFactory circuitBreakerFactory;

    public  BuscarController(CircuitBreakerFactory circuitBreakerFactory) {
        this.circuitBreakerFactory = circuitBreakerFactory;
    }

    @GetMapping(value="/rh/filtrarempleado/{word}/{order}",  produces="application/json")
    public String listarBuscar(@PathVariable("word") String item_a,
                                @PathVariable("order") String item_b)
    {
        String listar = serviceBuscarClient.xxxxxxxxxxxxxxxxxx(item_b);

        Gson gson = new Gson();
        Type listType = new TypeToken<List<Employee>>() {}.getType();

        ArrayList<Employee> gsonList = gson.fromJson(listar, listType);

        ArrayList<Employee> buscarempleado = new ArrayList<>();

        for (Employee employee : gsonList) {

            if (item_b.toLowerCase().equals("firstname")) {
                if (employee.getFirstName().indexOf(item_a) == 0) {
                    System.out.println(employee.getFirstName());
                    buscarempleado.add(employee);
                }
            } else if (item_b.toLowerCase().equals("lastname")) {
                if (employee.getLastName().indexOf(item_a) == 0) {
                    System.out.println(employee.getLastName());
                    buscarempleado.add(employee);
                }
            } else if (item_b.toLowerCase().equals("jobtitle")) {
                if (employee.getJob().getJobTitle().indexOf(item_a) == 0) {
                    System.out.println(employee.getJob().getJobTitle());
                    buscarempleado.add(employee);
                }
            }

        }

            return gson.toJson(xxxxxxxxxxxxxxxxxxx);

    }
}
