package com.example.demo_examenfinal_2025_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class EFBuscar20252Application {

    public static void main(String[] args) {
        SpringApplication.run(EFBuscar20252Application.class, args);
    }

}
