package com.example.demo_examenfinal_2025_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfBuscar20241ApplicationTests {

    @Test
    void contextLoads() {
    }

}
