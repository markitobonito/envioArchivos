package com.example.fc_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FcGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(FcGatewayApplication.class, args);
    }

}
