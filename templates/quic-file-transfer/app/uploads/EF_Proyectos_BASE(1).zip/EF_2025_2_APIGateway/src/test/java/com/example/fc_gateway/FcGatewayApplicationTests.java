package com.example.fc_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FcGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
