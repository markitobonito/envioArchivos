package com.example.demo_examenfinal_2025_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EFListar20252Application {

    public static void main(String[] args) {
        SpringApplication.run(EFListar20252Application.class, args);
    }

}
