package com.example.demo_examenfinal_2025_2.controller;

import com.example.demo_examenfinal_2025_2.entity.Employee;
import com.example.demo_examenfinal_2025_2.repository.EmployeeRepository;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@xxxxxxxxxxx
@RequestMapping("xxxx")
public class EmployeeController {

    final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @GetMapping(value="/ordenarpor/{ordercolum}", produces="application/json")
    public List<Employee> listaEmpleados(xxxxxxxxx String  ordercolum)

    {
        if (ordercolum.toLowerCase().equals("firstname")) {
            ordercolum = "firstName";
        } else if (ordercolum.toLowerCase().equals("lastname")) {
            ordercolum = "lastName";
        } else if (ordercolum.toLowerCase().equals("jobtitle")) {
            ordercolum = "jobID.jobTitle";
        }
        return employeeRepository.xxxxxxx(Sort.by(Sort.Direction.ASC, ordercolum));
    }

    @GetMapping(value = {"", "/"}, produces="application/json")
    public List<Employee> listEmpleados()
    { return employeeRepository.xxxxxxx;}

    @GetMapping(value="/{id}", produces="application/json")
    public Employee infoEmpleados(xxxxxxxxxxxxxx Integer id)

    {
        return employeeRepository.findById(id).get();
    }

    @PostMapping(value = {"", "/"}, consumes = "application/json", produces = "application/json")
    public ResponseEntity<HashMap<String, Object>> agregarEmpleado(
            @RequestBody Employee newEmployee) {
        employeeRepository.save(newEmployee);
        HashMap<String, Object> responseJson = new HashMap<>();
        responseJson.put("id", newEmployee.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(responseJson);
    }




}
