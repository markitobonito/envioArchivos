package com.example.demo_examenfinal_2025_2.repository;

import com.example.demo_examenfinal_2025_2.entity.Job;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepository extends JpaRepository<Job, String> {
}
